#ifndef ENCRIPTION_CONTROLLER_H
#define ENCRIPTION_CONTROLLER_H
#include <QString>
#include <QObject>

class Encriptioncontroller:public QObject
{
    Q_OBJECT
public:
    // Encriptioncontroller();
    explicit Encriptioncontroller(QObject *parent = nullptr);
    QString soursefile;

    signals:
    void sendToQml(QString codetext);
public slots:

   bool encriptFile(const QString & mkey, const QString &in_file);
   bool decriptFile(const QString & mkey, const QString &in_file);
private: // они все начинаются с m_
    unsigned char * key = (unsigned char *)("32101230123456789873874547898765"); //32 символа
    QString key2;

protected:
    QObject *EncryptFile;
};

#endif // ENCRIPTION_CONTROLLER_H
